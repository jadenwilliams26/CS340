#Jaden Williams
#SNHU - CS340
#3/29/25
#4-1 Milestone

from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter:
    # CRUD operations in MongoDB
    
    def __init__(self, USER, PASS):
        # Initialize the MongoClient
        HOST = 'nv-desktop-services.apporto.com'
        PORT = 34964
        DB = 'AAC'
        COL = 'animals'

        # Initialize connection
        self.client = MongoClient(f'mongodb://{USER}:{PASS}@{HOST}:{PORT}')
        self.database = self.client[DB]
        self.collection = self.database[COL]
    
    # Create - Add a new animal record
    def create(self, data):
        if data:
            insert_result = self.collection.insert_one(data)
            return insert_result.inserted_id  # Return the inserted ID
        else:
            raise ValueError("Nothing to save. Data parameter is empty.")
        
    # Read - Retrieve animal records based on search criteria
    def read(self, find_data=None):
        if find_data:
            input_data = self.collection.find(find_data, {"_id": False})
        else:
            input_data = self.collection.find({}, {"_id": False})
        return list(input_data)  # Convert cursor to list for easier handling
    
    # Update - Modify an existing animal record
    def update(self, find_data, new_data):
        if not find_data or not new_data:
            raise ValueError("Both find_data and new_data must be provided.")
        
        update_result = self.collection.update_many(find_data, {"$set": new_data})
        return update_result.modified_count  # Return number of modified records
    
    # Delete - Remove an animal record
    def delete(self, remove_data):
        if not remove_data:
            raise ValueError("remove_data parameter cannot be empty.")
        
        delete_result = self.collection.delete_many(remove_data)
        return delete_result.deleted_count  # Return number of deleted records
